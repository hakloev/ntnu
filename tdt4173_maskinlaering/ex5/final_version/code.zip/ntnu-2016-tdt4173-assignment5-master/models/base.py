import abc


class BaseModel(object):
    __metaclass__ = abc.ABCMeta

    def __init__(self):
        pass
